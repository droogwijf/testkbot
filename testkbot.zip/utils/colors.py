class EmbedColors:
    YELLOW = 0xFADB5E
    ORANGE = 0xFFA500
    RED = 0xFF4747
    BLUE = 0x00A8FF
    GREEN = 0x43B581
