from utils.templates.bans import (
    get_embed_ban,  # noqa: F401
    get_embed_ban_dm,  # noqa: F401
    get_embed_bans_list,  # noqa: F401
)
from utils.templates.kick import (
    get_embed_kick,  # noqa: F401
    get_embed_kick_dm,  # noqa: F401
)
from utils.templates.logs import get_embed_mod_log  # noqa: F401
from utils.templates.mutes import (
    get_embed_mute,  # noqa: F401
    get_embed_mute_dm,  # noqa: F401
    get_embed_mutes_alert,  # noqa: F401
    get_embed_mutes_list,  # noqa: F401
)
from utils.templates.system import get_embed_confirm, get_embed_error  # noqa: F401
from utils.templates.warns import (
    get_embed_clear_warns,  # noqa: F401
    get_embed_warnings_list,  # noqa: F401
    get_embed_warns,  # noqa: F401
    get_embed_warns_alert,  # noqa: F401
    get_embed_warns_dm,  # noqa: F401
)
