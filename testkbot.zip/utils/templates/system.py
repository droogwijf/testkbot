import discord

from ..colors import EmbedColors


def get_embed_confirm(message):
    """Embed voor succesvolle acties."""
    return discord.Embed(description=f"✅ {message}", color=EmbedColors.GREEN)


def get_embed_error(message):
    """Embed voor foutmeldingen."""
    return discord.Embed(description=f"❌ {message}", color=EmbedColors.RED)


def get_embed_history(gebruiker, warns, mutes, kicks, bans):
    """
    Genereert een volledig overzicht van alle straffen voor een gebruiker.
    """
    embed = discord.Embed(
        title=f"Moderatie Historie: {gebruiker.name}",
        color=discord.Color.blue(),
        timestamp=discord.utils.utcnow(),
    )
    embed.set_thumbnail(url=gebruiker.display_avatar.url)

    # Bereken het totaal van alle categorieën
    total_infractions = len(warns) + len(mutes) + len(kicks) + len(bans)
    embed.description = f"Totaal aantal overtredingen: **{total_infractions}**"

    # --- Bans Sectie ---
    if bans:
        text = ""
        for c in reversed(bans):
            # We tonen de duur erbij (bijv. "7d" of "Permanent")
            duur = c.get("duration", "Permanent")
            text += f"• **ID: {c['case_id']}** | {c['reason']} (*{duur}*)\n"
        embed.add_field(name=f"Bans ({len(bans)})", value=text, inline=False)
    else:
        embed.add_field(name="Bans", value="Geen ban historie.", inline=False)

    # --- Waarschuwingen Sectie ---
    if warns:
        text = ""
        for c in reversed(warns):
            text += f"• **ID: {c['case_id']}** | {c['reason']}\n"
        embed.add_field(name=f"Waarschuwingen ({len(warns)})", value=text, inline=False)
    else:
        embed.add_field(
            name="Waarschuwingen", value="Geen warn historie.", inline=False
        )

    # --- Mutes Sectie ---
    if mutes:
        text = ""
        for c in reversed(mutes):
            text += f"• **ID: {c['case_id']}** | {c['reason']} ({c['duration']})\n"
        embed.add_field(name=f"Mutes ({len(mutes)})", value=text, inline=False)
    else:
        embed.add_field(name="Mutes", value="Geen mute historie.", inline=False)

    # --- Kicks Sectie ---
    if kicks:
        text = ""
        for c in reversed(kicks):
            text += f"• **ID: {c['case_id']}** | {c['reason']}\n"
        embed.add_field(name=f"Kicks ({len(kicks)})", value=text, inline=False)
    else:
        embed.add_field(name="Kicks", value="Geen kick historie.", inline=False)

    embed.set_footer(text=f"User ID: {gebruiker.id}")
    return embed
