from datetime import datetime

import discord

from ..colors import EmbedColors


def format_duration(dur_str):
    if not dur_str:
        return "Onbekend"

    hoeveelheid = dur_str[:-1]
    eenheid = dur_str[-1].lower()

    if eenheid == "m":
        return f"{hoeveelheid} minuten"
    elif eenheid == "h":
        return f"{hoeveelheid} uur"
    elif eenheid == "d":
        return f"{hoeveelheid} dagen"

    return dur_str


# Mute embed voor #straffen
def get_embed_mute(gebruiker, moderator, reden, duur, case_id):
    embed = discord.Embed(
        title=f"Case {case_id} | Timeout | {gebruiker.name}",
        color=EmbedColors.ORANGE,
        timestamp=datetime.now(),
    )
    embed.add_field(name="Gebruiker", value=gebruiker.mention, inline=True)
    embed.add_field(name="Moderator", value=moderator.mention, inline=True)
    embed.add_field(name="Duur", value=duur, inline=True)
    embed.add_field(name="Reden", value=reden, inline=False)
    embed.set_footer(text=f"User ID: {gebruiker.id}")
    return embed


# Muteslist embed
def get_embed_mutes_list(gebruiker, cases):
    embed = discord.Embed(color=EmbedColors.ORANGE)

    aantal = len(cases)
    woord = "Timeout" if aantal == 1 else "Timeouts"

    embed.title = f"{aantal} {woord} voor {gebruiker.name}"

    if not cases:
        embed.description = "Geen timeouts gevonden."
    else:
        desc = ""
        for c in reversed(cases[-10:]):
            ts = int(c.get("timestamp", datetime.now().timestamp()))

            nette_duur = format_duration(c.get("duration", ""))

            desc += (
                f"**Case {c['case_id']}**\n"
                f"Moderator: {c['mod_name']}\n"
                f"Reden: {c['reason']}\n"
                f"Duur: {nette_duur}\n"
                f"<t:{ts}:f>\n\n"
            )
        embed.description = desc

    embed.set_footer(text=f"User ID: {gebruiker.id}")
    return embed


# Mute embed voor DM
def get_embed_mute_dm(guild_name: str, reden: str, duur: str):
    nette_duur = format_duration(duur)
    embed = discord.Embed(
        title="Server Timeout",
        color=EmbedColors.ORANGE,
        timestamp=datetime.now(),
    )
    embed.add_field(name="Server", value=guild_name, inline=True)
    embed.add_field(name="Duur", value=nette_duur, inline=True)
    embed.add_field(name="Reden", value=reden, inline=False)

    embed.set_footer(
        text="Gedurende de timeout kun je geen berichten sturen of deelnemen aan spraakkanalen."
    )
    return embed


# 3 mutes embed voor #helperschat
def get_embed_mutes_alert(gebruiker, mute_count):
    embed = discord.Embed(
        title="⚠️ 3de Timeout Bereikt",
        description=f"{gebruiker.mention} heeft nu **{mute_count} timeouts** gehad. Mogelijk zijn er verdere maatregelen nodig.",
        color=EmbedColors.RED,
    )
    embed.set_footer(text=f"User ID: {gebruiker.id}")
    return embed
