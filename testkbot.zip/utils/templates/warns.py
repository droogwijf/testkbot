from datetime import datetime

import discord

from ..colors import EmbedColors


# Warn embed voor #straffen
def get_embed_warns(gebruiker, moderator, reden, case_id):
    embed = discord.Embed(
        title=f"Case {case_id} | Waarschuwing | {gebruiker.name}",
        color=EmbedColors.YELLOW,
        timestamp=datetime.now(),
    )
    embed.add_field(name="Gebruiker", value=gebruiker.mention, inline=True)
    embed.add_field(name="Moderator", value=moderator.mention, inline=True)
    embed.add_field(name="Reden", value=reden, inline=True)
    embed.set_footer(text=f"User ID: {gebruiker.id}")
    return embed


# Warnlist embed
def get_embed_warnings_list(gebruiker, user_cases):
    embed = discord.Embed(color=EmbedColors.YELLOW)

    aantal = len(user_cases)
    woord = "Waarschuwing" if aantal == 1 else "Waarschuwingen"

    embed.title = f"{aantal} {woord} voor {gebruiker.name}"

    if not user_cases:
        embed.description = "Geen waarschuwingen gevonden."
    else:
        desc = ""
        for c in reversed(user_cases[-10:]):
            ts = int(c.get("timestamp", datetime.now().timestamp()))
            desc += f"**Case {c['case_id']}**\nModerator: {c['mod_name']}\nReden: {c['reason']}\n<t:{ts}:f>\n\n"
        embed.description = desc

    embed.set_footer(text=f"User ID: {gebruiker.id}")
    return embed


# Clear warns embed
def get_embed_clear_warns(gebruiker, moderator):
    embed = discord.Embed(
        title=f"Warnings Cleared | {gebruiker.name}",
        description=f"Alle waarschuwingen voor {gebruiker.mention} zijn verwijderd.",
        color=EmbedColors.GREEN,
        timestamp=datetime.now(),
    )
    embed.add_field(name="User", value=gebruiker.mention, inline=True)
    embed.add_field(name="Moderator", value=moderator.mention, inline=True)
    embed.set_footer(text=f"ID: {gebruiker.id}")
    return embed


# Warn embed voor DM
def get_embed_warns_dm(guild_name: str, reden: str):
    embed = discord.Embed(
        title="Server Waarschuwing",
        color=EmbedColors.YELLOW,
        timestamp=discord.utils.utcnow(),
    )
    embed.add_field(name="Server", value=guild_name, inline=True)
    embed.add_field(name="Reden", value=reden, inline=True)

    embed.set_footer(
        text="Let op: Herhaaldelijke overtredingen kunnen leiden tot verdere maatregelen."
    )
    return embed


# 3 warns embed voor #helperschat
def get_embed_warns_alert(gebruiker, warn_count):
    embed = discord.Embed(
        title="⚠️ 3de Waarschuwing Bereikt",
        description=f"{gebruiker.mention} heeft nu **{warn_count} waarschuwingen**. Mogelijk zijn er verdere maatregelen nodig.",
        color=EmbedColors.RED,
    )
    embed.set_footer(text=f"User ID: {gebruiker.id}")
    return embed
