from datetime import datetime

import discord

from ..colors import EmbedColors


# Kick embed voor #straffen
def get_embed_kick(gebruiker, moderator, reden, case_id):
    embed = discord.Embed(
        title=f"Case {case_id} | Kick | {gebruiker.name}",
        color=EmbedColors.ORANGE,
        timestamp=datetime.now(),
    )
    embed.add_field(name="Gebruiker", value=gebruiker.mention, inline=True)
    embed.add_field(name="Moderator", value=moderator.mention, inline=True)
    embed.add_field(name="Reden", value=reden, inline=False)
    embed.set_footer(text=f"User ID: {gebruiker.id}")
    return embed


# Kick embed voor DM
def get_embed_kick_dm(guild_name: str, reden: str):
    embed = discord.Embed(
        title="Server Kick",
        color=EmbedColors.ORANGE,
        timestamp=discord.utils.utcnow(),
    )
    embed.add_field(name="Server", value=guild_name, inline=True)
    embed.add_field(name="Reden", value=reden, inline=True)

    embed.set_footer(
        text="Je kunt deze server altijd opnieuw joinen als je denkt dat dit een vergissing is."
    )
    return embed
