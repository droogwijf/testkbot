from datetime import datetime

import discord

from ..colors import EmbedColors


def get_embed_mod_log(
    moderator, user, action, reason=None, case_id=None, channel=None, command_name=None
):
    embed = discord.Embed(color=EmbedColors.BLUE)
    embed.set_author(name=moderator.name, icon_url=moderator.display_avatar.url)

    location = f" in {channel.mention}" if channel else ""

    # Bepaal de titel tekst
    title_text = (
        f"Used `{command_name}` command{location}"
        if command_name
        else "Used `Action Button`"
    )

    # Logica voor de verschillende acties
    if action == "WARN":
        description = f"/warn user: {user.id} reason: {reason}"

    elif action == "TIMEOUT":
        description = f"/mute user: {user.id} reason: {reason}"

    elif action == "KICK":
        description = f"/kick user: {user.id} reason: {reason}"

    elif action == "BAN":
        description = f"/ban user: {user.id} reason: {reason}"

    elif action == "TEMPBAN":
        description = f"/tempban user: {user.id} reason: {reason}"

    elif action == "UNMUTE":
        description = f"/unmute user: {user.id}"

    elif action == "UNBAN":
        description = f"Unbanned user: {user.id}"

    elif action in ["VIEW", "VIEW_MUTES", "VIEW_BANLIST", "VIEW_HISTORY"]:
        description = f"Action: VIEW {action.replace('VIEW_', '')} on {user.id}"

    elif action == "DELETE":
        description = f"Removed Case: {case_id}"

    elif action == "CLEAR_WARNS":
        description = f"/clearwarns user: {user.id}"

    else:
        description = f"Action: {action} on {user.id if user else 'Unknown'}"

    embed.description = f"{title_text}\n{description}"
    embed.timestamp = datetime.now()

    return embed
