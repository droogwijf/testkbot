from datetime import datetime

import discord

from ..colors import EmbedColors


def format_duration(dur_str):
    if not dur_str:
        return "Permanent"
    hoeveelheid = dur_str[:-1]
    eenheid = dur_str[-1].lower()
    if eenheid == "m":
        return f"{hoeveelheid} minuten"
    if eenheid == "h":
        return f"{hoeveelheid} uur"
    if eenheid == "d":
        return f"{hoeveelheid} dagen"
    if eenheid == "w":
        return f"{hoeveelheid} weken"
    return dur_str


# Ban embed voor #straffen
def get_embed_ban(gebruiker, moderator, reden, case_id, duur=None):
    titel = "Ban" if not duur else "Tempban"
    embed = discord.Embed(
        title=f"Case {case_id} | {titel} | {gebruiker.name}",
        color=EmbedColors.RED,
        timestamp=datetime.now(),
    )
    embed.add_field(name="Gebruiker", value=gebruiker.mention, inline=True)
    embed.add_field(name="Moderator", value=moderator.mention, inline=True)
    if duur:
        embed.add_field(name="Duur", value=format_duration(duur), inline=True)
    embed.add_field(name="Reden", value=reden, inline=False)
    embed.set_footer(text=f"User ID: {gebruiker.id}")
    return embed


# Ban DM embed
def get_embed_ban_dm(guild_name, reden, duur=None):
    titel = "Server Verbanning" if not duur else "Tijdelijke Verbanning"
    embed = discord.Embed(
        title=titel,
        color=EmbedColors.RED,
        timestamp=datetime.now(),
    )
    embed.add_field(name="Server", value=guild_name, inline=True)
    if duur:
        embed.add_field(name="Duur", value=format_duration(duur), inline=True)
    embed.add_field(name="Reden", value=reden, inline=False)
    footer = (
        "Dit is een permanente ban."
        if not duur
        else "Na de duur kun je de server weer joinen."
    )
    embed.set_footer(text=footer)
    return embed


# Banlist embed
def get_embed_bans_list(gebruiker, cases):
    embed = discord.Embed(color=EmbedColors.RED)
    aantal = len(cases)
    embed.title = f"{aantal} Ban(s) voor {gebruiker.name}"
    if not cases:
        embed.description = "Geen ban historie gevonden."
    else:
        desc = ""
        for c in reversed(cases[-10:]):
            ts = int(c.get("timestamp", datetime.now().timestamp()))
            duur_str = c.get("duration", "Permanent")
            desc += f"**Case {c['case_id']}** ({duur_str})\nMod: {c['mod_name']}\nReden: {c['reason']}\n<t:{ts}:f>\n\n"
        embed.description = desc
    embed.set_footer(text=f"User ID: {gebruiker.id}")
    return embed
