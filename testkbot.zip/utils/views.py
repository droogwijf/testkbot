import discord

from utils.templates import get_embed_confirm, get_embed_error


class DeleteWarnModal(discord.ui.Modal, title="Verwijder Waarschuwing"):
    case_input = discord.ui.TextInput(
        label="Case ID",
        placeholder="Case ID (bijv. 1)",
        min_length=1,
        max_length=3,
    )

    def __init__(self, cog):
        super().__init__()
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction):
        try:
            if not self.cog:
                self.cog = interaction.client.get_cog("Warnlist")

            case_id = int(self.case_input.value)
            data = self.cog.get_data()
            original_len = len(data["cases"])

            data["cases"] = [c for c in data["cases"] if c["case_id"] != case_id]

            if len(data["cases"]) == original_len:
                return await interaction.response.send_message(
                    embed=get_embed_error(f"Case {case_id} niet gevonden."),
                    ephemeral=True,
                )

            self.cog.save_data(data)
            await interaction.response.send_message(
                embed=get_embed_confirm(f"Case **{case_id}** is verwijderd.")
            )

            await self.cog.log_to_mod_logs(
                interaction, action="DELETE", case_id=case_id
            )

        except Exception as e:
            await interaction.response.send_message(
                embed=get_embed_error(f"Er ging iets mis: {e}"), ephemeral=True
            )


class WarningView(discord.ui.View):
    def __init__(self, cog=None):
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(
        label="Delete a warning",
        style=discord.ButtonStyle.danger,
        emoji="🗑️",
        custom_id="persistent:delete_warn_button",
    )
    async def delete_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        if self.cog is None:
            self.cog = interaction.client.get_cog("Warnlist")

        await interaction.response.send_modal(DeleteWarnModal(self.cog))
