import json
import os
from datetime import datetime

import discord
from discord import app_commands
from discord.ext import commands

from utils.templates import (
    get_embed_clear_warns,
    get_embed_confirm,
    get_embed_error,
    get_embed_mod_log,
    get_embed_warnings_list,
    get_embed_warns,
    get_embed_warns_alert,
    get_embed_warns_dm,
)
from utils.views import WarningView


class Warnings(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.warnings_file = "data/warnings.json"

    def get_data(self):
        if not os.path.exists(self.warnings_file):
            if not os.path.exists("data"):
                os.makedirs("data")
            with open(self.warnings_file, "w") as f:
                json.dump({"cases": []}, f)
            return {"cases": []}
        with open(self.warnings_file, "r") as f:
            try:
                return json.load(f)
            except Exception:
                return {"cases": []}

    def save_data(self, data):
        with open(self.warnings_file, "w") as f:
            json.dump(data, f, indent=4)

    async def log_to_mod_logs(
        self,
        interaction,
        action,
        user=None,
        reason=None,
        case_id=None,
        command_name=None,
    ):
        mod_log_id = os.getenv("CHANNEL_MOD_LOGS_ID")
        if not mod_log_id:
            return

        ch = interaction.guild.get_channel(int(mod_log_id))
        if ch:
            embed = get_embed_mod_log(
                moderator=interaction.user,
                user=user,
                action=action,
                reason=reason,
                case_id=case_id,
                channel=interaction.channel,
                command_name=command_name,
            )
            await ch.send(embed=embed)

    @app_commands.command(
        name="warn", description="Geef een waarschuwing aan een gebruiker"
    )
    @app_commands.checks.has_permissions(moderate_members=True)
    async def warn(
        self, interaction: discord.Interaction, gebruiker: discord.Member, reden: str
    ):
        warn_data = self.get_data()
        mutes_cog = self.bot.get_cog("Mutes")
        kick_cog = self.bot.get_cog("Kick")

        mute_data = (
            mutes_cog.get_data()
            if mutes_cog and hasattr(mutes_cog, "get_data")
            else {"cases": []}
        )
        kick_data = (
            kick_cog.get_data()
            if kick_cog and hasattr(kick_cog, "get_data")
            else {"cases": []}
        )

        all_case_ids = (
            [c["case_id"] for c in warn_data["cases"]]
            + [c["case_id"] for c in mute_data["cases"]]
            + [c["case_id"] for c in kick_data["cases"]]
        )

        case_id = (max(all_case_ids) + 1) if all_case_ids else 1

        try:
            dm_embed = get_embed_warns_dm(interaction.guild.name, reden)
            await gebruiker.send(embed=dm_embed)
        except discord.Forbidden:
            pass
        except Exception:
            pass

        new_case = {
            "case_id": case_id,
            "user_id": gebruiker.id,
            "user_name": gebruiker.name,
            "mod_name": interaction.user.name,
            "reason": reden,
            "timestamp": datetime.now().timestamp(),
        }
        warn_data["cases"].append(new_case)
        self.save_data(warn_data)

        await interaction.response.send_message(
            embed=get_embed_confirm(f"**{gebruiker.name}** is gewaarschuwd.")
        )

        user_cases = [c for c in warn_data["cases"] if c["user_id"] == gebruiker.id]
        if len(user_cases) == 3:
            h_ch_id = os.getenv("CHANNEL_HELPERS_CHAT_ID")
            if h_ch_id:
                h_ch = interaction.guild.get_channel(int(h_ch_id))
                if h_ch:
                    await h_ch.send(embed=get_embed_warns_alert(gebruiker, 3))

        s_ch_id = os.getenv("CHANNEL_STRAFFEN_ID")
        if s_ch_id:
            s_ch = interaction.guild.get_channel(int(s_ch_id))
            if s_ch:
                embed = get_embed_warns(gebruiker, interaction.user, reden, case_id)
                await s_ch.send(embed=embed)

        await self.log_to_mod_logs(
            interaction,
            action="WARN",
            user=gebruiker,
            reason=reden,
            case_id=case_id,
            command_name="warn",
        )

    @app_commands.command(
        name="warnlist", description="Toon waarschuwingen van een gebruiker"
    )
    @app_commands.checks.has_permissions(moderate_members=True)
    async def warnlist(
        self, interaction: discord.Interaction, gebruiker: discord.Member
    ):
        data = self.get_data()
        user_cases = [c for c in data["cases"] if c["user_id"] == gebruiker.id]

        embed = get_embed_warnings_list(gebruiker, user_cases)
        await interaction.response.send_message(
            embed=embed, view=WarningView(self), ephemeral=True
        )

        await self.log_to_mod_logs(
            interaction, action="VIEW", user=gebruiker, command_name="warnlist"
        )

    @app_commands.command(
        name="clearwarns",
        description="Verwijder alle waarschuwingen van een gebruiker",
    )
    @app_commands.checks.has_permissions(moderate_members=True)
    async def clearwarns(
        self, interaction: discord.Interaction, gebruiker: discord.Member
    ):
        data = self.get_data()
        original_count = len([c for c in data["cases"] if c["user_id"] == gebruiker.id])

        if original_count == 0:
            return await interaction.response.send_message(
                embed=get_embed_error(
                    f"**{gebruiker.name}** heeft geen waarschuwingen."
                ),
                ephemeral=True,
            )

        data["cases"] = [c for c in data["cases"] if c["user_id"] != gebruiker.id]
        self.save_data(data)

        await interaction.response.send_message(
            embed=get_embed_confirm(
                f"Alle waarschuwingen ({original_count}) van **{gebruiker.name}** zijn gewist."
            ),
            ephemeral=True,
        )

        s_ch_id = os.getenv("CHANNEL_STRAFFEN_ID")
        if s_ch_id:
            s_ch = interaction.guild.get_channel(int(s_ch_id))
            if s_ch:
                await s_ch.send(
                    embed=get_embed_clear_warns(gebruiker, interaction.user)
                )

        await self.log_to_mod_logs(
            interaction,
            action="CLEAR_WARNS",
            user=gebruiker,
            reason=f"Cleared {original_count} warnings",
            command_name="clearwarns",
        )


async def setup(bot):
    await bot.add_cog(Warnings(bot))
