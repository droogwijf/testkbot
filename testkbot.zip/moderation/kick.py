import json
import os
from datetime import datetime

import discord
from discord import app_commands
from discord.ext import commands

from utils.templates import (
    get_embed_confirm,
    get_embed_error,
    get_embed_kick,
    get_embed_kick_dm,
    get_embed_mod_log,
)


class Kick(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.kicks_file = "data/kicks.json"

    def get_data(self):
        if not os.path.exists(self.kicks_file):
            if not os.path.exists("data"):
                os.makedirs("data")
            with open(self.kicks_file, "w") as f:
                json.dump({"cases": []}, f)
            return {"cases": []}
        with open(self.kicks_file, "r") as f:
            try:
                return json.load(f)
            except Exception:
                return {"cases": []}

    def save_data(self, data):
        with open(self.kicks_file, "w") as f:
            json.dump(data, f, indent=4)

    async def log_to_mod_logs(self, interaction, user, reason, case_id, command_name):
        mod_log_id = os.getenv("CHANNEL_MOD_LOGS_ID")
        if not mod_log_id:
            return

        ch = interaction.guild.get_channel(int(mod_log_id))
        if ch:
            embed = get_embed_mod_log(
                moderator=interaction.user,
                user=user,
                action="KICK",
                reason=reason,
                case_id=case_id,
                channel=interaction.channel,
                command_name=command_name,
            )
            await ch.send(embed=embed)

    @app_commands.command(
        name="kick", description="Verwijder een gebruiker van de server"
    )
    @app_commands.describe(
        gebruiker="De persoon die je wilt kicken", reden="De reden voor de kick"
    )
    @app_commands.checks.has_permissions(moderate_members=True)
    async def kick(
        self, interaction: discord.Interaction, gebruiker: discord.Member, reden: str
    ):
        if gebruiker.id == interaction.user.id:
            return await interaction.response.send_message(
                embed=get_embed_error("Je kunt jezelf niet kicken."), ephemeral=True
            )

        if gebruiker.top_role >= interaction.user.top_role:
            return await interaction.response.send_message(
                embed=get_embed_error(
                    "Je kunt deze persoon niet kicken vanwege hun rang."
                ),
                ephemeral=True,
            )

        try:
            kick_data = self.get_data()
            warns_cog = self.bot.get_cog("Warnings")
            mutes_cog = self.bot.get_cog("Mutes")

            warn_data = (
                warns_cog.get_data()
                if warns_cog and hasattr(warns_cog, "get_data")
                else {"cases": []}
            )
            mute_data = (
                mutes_cog.get_data()
                if mutes_cog and hasattr(mutes_cog, "get_data")
                else {"cases": []}
            )

            all_case_ids = (
                [c["case_id"] for c in kick_data["cases"]]
                + [c["case_id"] for c in warn_data["cases"]]
                + [c["case_id"] for c in mute_data["cases"]]
            )
            case_id = (max(all_case_ids) + 1) if all_case_ids else 1

            try:
                dm_embed = get_embed_kick_dm(interaction.guild.name, reden)
                await gebruiker.send(embed=dm_embed)
            except discord.Forbidden:
                pass
            except Exception:
                pass

            await gebruiker.kick(reason=reden)

            new_case = {
                "case_id": case_id,
                "user_id": gebruiker.id,
                "user_name": gebruiker.name,
                "mod_name": interaction.user.name,
                "reason": reden,
                "timestamp": datetime.now().timestamp(),
            }
            kick_data["cases"].append(new_case)
            self.save_data(kick_data)

            await interaction.response.send_message(
                embed=get_embed_confirm(f"**{gebruiker.name}** is succesvol gekickt."),
                ephemeral=True,
            )

            s_ch_id = os.getenv("CHANNEL_STRAFFEN_ID")
            if s_ch_id:
                s_ch = interaction.guild.get_channel(int(s_ch_id))
                if s_ch:
                    await s_ch.send(
                        embed=get_embed_kick(
                            gebruiker, interaction.user, reden, case_id
                        )
                    )

            await self.log_to_mod_logs(interaction, gebruiker, reden, case_id, "kick")

        except Exception as e:
            if interaction.response.is_done():
                await interaction.followup.send(
                    embed=get_embed_error(f"Fout bij het kicken: {e}"), ephemeral=True
                )
            else:
                await interaction.response.send_message(
                    embed=get_embed_error(f"Fout bij het kicken: {e}"), ephemeral=True
                )


async def setup(bot):
    await bot.add_cog(Kick(bot))
