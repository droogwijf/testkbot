import json
import os
from datetime import datetime, timedelta

import discord
from discord import app_commands
from discord.ext import commands

from utils.templates import (
    get_embed_confirm,
    get_embed_error,
    get_embed_mod_log,
    get_embed_mute,
    get_embed_mute_dm,
    get_embed_mutes_alert,
    get_embed_mutes_list,
)


class Mutes(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.mutes_file = "data/mutes.json"

    def get_data(self):
        if not os.path.exists(self.mutes_file):
            if not os.path.exists("data"):
                os.makedirs("data")
            with open(self.mutes_file, "w") as f:
                json.dump({"cases": []}, f)
            return {"cases": []}
        with open(self.mutes_file, "r") as f:
            try:
                return json.load(f)
            except Exception:
                return {"cases": []}

    def save_data(self, data):
        with open(self.mutes_file, "w") as f:
            json.dump(data, f, indent=4)

    async def log_to_mod_logs(
        self, interaction, action, user, reason=None, case_id=None, command_name=None
    ):
        """Stuurt de log direct naar het mod-logs kanaal in de juiste stijl."""
        mod_log_id = os.getenv("CHANNEL_MOD_LOGS_ID")
        if not mod_log_id:
            return

        ch = interaction.guild.get_channel(int(mod_log_id))
        if ch:
            embed = get_embed_mod_log(
                moderator=interaction.user,
                user=user,
                action=action,
                reason=reason,
                case_id=case_id,
                channel=interaction.channel,
                command_name=command_name,
            )
            await ch.send(embed=embed)

    @app_commands.command(
        name="mute",
        description="Geef een timeout aan een gebruiker",
    )
    @app_commands.describe(
        duur="Bijv: 10m (minuten), 2h (uren), 1d (dagen)", reden="Reden voor de mute"
    )
    @app_commands.checks.has_permissions(moderate_members=True)
    async def mute(
        self,
        interaction: discord.Interaction,
        gebruiker: discord.Member,
        duur: str,
        reden: str,
    ):
        if gebruiker.top_role >= interaction.user.top_role:
            return await interaction.response.send_message(
                embed=get_embed_error("Je kunt deze persoon niet muten."),
                ephemeral=True,
            )

        duur_input = duur.lower().strip()
        hoeveelheid = duur_input[:-1]
        eenheid = duur_input[-1]

        if not hoeveelheid.isdigit():
            return await interaction.response.send_message(
                embed=get_embed_error(
                    "Ongeldig formaat. Gebruik bijv: `10m`, `2h` of `1d`."
                ),
                ephemeral=True,
            )

        minuten = int(hoeveelheid)
        display_duur = ""

        if eenheid == "m":
            display_duur = f"{minuten} minuten"
        elif eenheid == "h":
            display_duur = f"{minuten} uur"
            minuten *= 60
        elif eenheid == "d":
            display_duur = f"{minuten} dag(en)"
            minuten *= 1440
        else:
            return await interaction.response.send_message(
                embed=get_embed_error("Gebruik een geldige eenheid: `m`, `h`, of `d`."),
                ephemeral=True,
            )

        if minuten > 40320:
            return await interaction.response.send_message(
                embed=get_embed_error("Een timeout mag maximaal 28 dagen duren."),
                ephemeral=True,
            )

        mute_data = self.get_data()
        warns_cog = self.bot.get_cog("Warnings")
        kick_cog = self.bot.get_cog("Kick")

        warn_data = (
            warns_cog.get_data()
            if warns_cog and hasattr(warns_cog, "get_data")
            else {"cases": []}
        )
        kick_data = (
            kick_cog.get_data()
            if kick_cog and hasattr(kick_cog, "get_data")
            else {"cases": []}
        )

        all_case_ids = (
            [c["case_id"] for c in mute_data["cases"]]
            + [c["case_id"] for c in warn_data["cases"]]
            + [c["case_id"] for c in kick_data["cases"]]
        )

        case_id = (max(all_case_ids) + 1) if all_case_ids else 1
        duur_delta = timedelta(minutes=minuten)

        try:
            try:
                dm_embed = get_embed_mute_dm(interaction.guild.name, reden, duur_input)
                await gebruiker.send(embed=dm_embed)
            except:  # noqa: E722
                pass

            await gebruiker.timeout(duur_delta, reason=reden)

            new_case = {
                "case_id": case_id,
                "user_id": gebruiker.id,
                "user_name": gebruiker.name,
                "mod_name": interaction.user.name,
                "reason": reden,
                "duration": duur_input,
                "timestamp": datetime.now().timestamp(),
            }
            mute_data["cases"].append(new_case)
            self.save_data(mute_data)

            await interaction.response.send_message(
                embed=get_embed_confirm(
                    f"**{gebruiker.name}** is gemute voor **{display_duur}**."
                ),
                ephemeral=True,
            )

            s_ch_id = os.getenv("CHANNEL_STRAFFEN_ID")
            if s_ch_id:
                s_ch = interaction.guild.get_channel(int(s_ch_id))
                if s_ch:
                    await s_ch.send(
                        embed=get_embed_mute(
                            gebruiker, interaction.user, reden, duur_input, case_id
                        )
                    )

            user_cases = [c for c in mute_data["cases"] if c["user_id"] == gebruiker.id]
            if len(user_cases) == 3:
                h_ch_id = os.getenv("CHANNEL_HELPERS_CHAT_ID")
                if h_ch_id:
                    h_ch = interaction.guild.get_channel(int(h_ch_id))
                    if h_ch:
                        await h_ch.send(embed=get_embed_mutes_alert(gebruiker, 3))

            await self.log_to_mod_logs(
                interaction=interaction,
                action="TIMEOUT",
                user=gebruiker,
                reason=f"{reden} ({duur_input})",
                case_id=case_id,
                command_name="mute",
            )

        except Exception as e:
            error_msg = f"Kon timeout niet toepassen: {e}"
            if interaction.response.is_done():
                await interaction.followup.send(
                    embed=get_embed_error(error_msg), ephemeral=True
                )
            else:
                await interaction.response.send_message(
                    embed=get_embed_error(error_msg), ephemeral=True
                )

    @app_commands.command(
        name="unmute", description="Verwijder de timeout van een gebruiker"
    )
    @app_commands.checks.has_permissions(moderate_members=True)
    async def unmute(self, interaction: discord.Interaction, gebruiker: discord.Member):
        try:
            await gebruiker.timeout(None)
            await interaction.response.send_message(
                embed=get_embed_confirm(
                    f"Timeout voor **{gebruiker.name}** verwijderd."
                ),
                ephemeral=True,
            )

            await self.log_to_mod_logs(
                interaction=interaction,
                action="UNMUTE",
                user=gebruiker,
                command_name="unmute",
            )
        except Exception as e:
            await interaction.response.send_message(
                embed=get_embed_error(f"Kon unmute niet uitvoeren: {e}"), ephemeral=True
            )

    @app_commands.command(
        name="mutelist", description="Toon timeout overzicht van een gebruiker"
    )
    @app_commands.checks.has_permissions(moderate_members=True)
    async def mutelist(
        self, interaction: discord.Interaction, gebruiker: discord.Member
    ):
        data = self.get_data()
        user_cases = [c for c in data["cases"] if c["user_id"] == gebruiker.id]

        embed = get_embed_mutes_list(gebruiker, user_cases)
        await interaction.response.send_message(embed=embed, ephemeral=True)

        await self.log_to_mod_logs(
            interaction, action="VIEW_MUTES", user=gebruiker, command_name="mutelist"
        )


async def setup(bot):
    await bot.add_cog(Mutes(bot))
