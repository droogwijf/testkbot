import os
import re
from datetime import datetime, timedelta

import discord
from discord import app_commands
from discord.ext import commands, tasks

from utils.templates import get_embed_confirm, get_embed_error, get_embed_mod_log
from utils.templates.bans import get_embed_ban, get_embed_ban_dm


class TempBans(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.check_tempbans.start()

    def cog_unload(self):
        self.check_tempbans.cancel()

    def parse_duration(self, duration: str):
        """Zet 1m, 1h, 1d, 1w om naar een timedelta object."""
        match = re.match(r"(\d+)([mhdw])", duration.lower())
        if not match:
            return None

        amount, unit = match.groups()
        amount = int(amount)

        if unit == "m":
            return timedelta(minutes=amount)
        if unit == "h":
            return timedelta(hours=amount)
        if unit == "d":
            return timedelta(days=amount)
        if unit == "w":
            return timedelta(weeks=amount)
        return None

    @tasks.loop(minutes=1)
    async def check_tempbans(self):
        """Controleert elke minuut of er bans zijn die opgeheven moeten worden."""
        bans_cog = self.bot.get_cog("Bans")
        if not bans_cog:
            return

        data = bans_cog.get_data()
        now = datetime.now().timestamp()
        changed = False

        for case in data["cases"][:]:
            if (
                case.get("duration")
                and case["duration"] != "Permanent"
                and "expiry" in case
            ):
                if now >= case["expiry"]:
                    for guild in self.bot.guilds:
                        try:
                            user = discord.Object(id=case["user_id"])
                            await guild.unban(
                                user,
                                reason=f"Tempban verlopen (Case #{case['case_id']})",
                            )

                            case["duration"] = f"Verlopen ({case['duration']})"
                            del case["expiry"]
                            changed = True
                        except:  # noqa: E722
                            continue

        if changed:
            bans_cog.save_data(data)

    @app_commands.command(name="tempban", description="Ban een gebruiker tijdelijk")
    @app_commands.describe(
        duur="Bijv: 10m, 2h, 7d, 1w",
        wis_berichten="Berichtgeschiedenis wissen (0-7 dagen)",
    )
    @app_commands.checks.has_permissions(ban_members=True)
    async def tempban(
        self,
        interaction: discord.Interaction,
        gebruiker: discord.User,
        duur: str,
        reden: str,
        wis_berichten: int = 0,
    ):
        duration_delta = self.parse_duration(duur)
        if not duration_delta:
            return await interaction.response.send_message(
                embed=get_embed_error(
                    "Ongeldige tijdsaanduiding! Gebruik bijv: `10m`, `2h`, `7d` of `1w`."
                ),
                ephemeral=True,
            )

        bans_cog = self.bot.get_cog("Bans")
        if not bans_cog:
            return await interaction.response.send_message("Bans module niet geladen.")

        all_ids = [c["case_id"] for c in bans_cog.get_data()["cases"]]
        for cog_name in ["Warnings", "Mutes", "Kick"]:
            cog = self.bot.get_cog(cog_name)
            if cog and hasattr(cog, "get_data"):
                all_ids.extend([c["case_id"] for c in cog.get_data()["cases"]])

        case_id = (max(all_ids) + 1) if all_ids else 1
        expiry_timestamp = (datetime.now() + duration_delta).timestamp()

        try:
            await gebruiker.send(
                embed=get_embed_ban_dm(interaction.guild.name, reden, duur)
            )
        except:  # noqa: E722
            pass

        try:
            days = max(0, min(wis_berichten, 7))
            await interaction.guild.ban(
                gebruiker,
                reason=f"Case {case_id} | Tempban {duur} | {reden}",
                delete_message_days=days,
            )

            data = bans_cog.get_data()
            new_case = {
                "case_id": case_id,
                "user_id": gebruiker.id,
                "user_name": gebruiker.name,
                "mod_name": interaction.user.name,
                "reason": reden,
                "duration": duur,
                "expiry": expiry_timestamp,
                "timestamp": datetime.now().timestamp(),
            }
            data["cases"].append(new_case)
            bans_cog.save_data(data)

            await interaction.response.send_message(
                embed=get_embed_confirm(
                    f"**{gebruiker.name}** is verbannen voor {duur}."
                ),
                ephemeral=True,
            )

            s_ch_id = os.getenv("CHANNEL_STRAFFEN_ID")
            if s_ch_id:
                s_ch = interaction.guild.get_channel(int(s_ch_id))
                if s_ch:
                    await s_ch.send(
                        embed=get_embed_ban(
                            gebruiker, interaction.user, reden, case_id, duur
                        )
                    )

            mod_log_id = os.getenv("CHANNEL_MOD_LOGS_ID")
            if mod_log_id:
                ch = interaction.guild.get_channel(int(mod_log_id))
                if ch:
                    embed = get_embed_mod_log(
                        interaction.user,
                        gebruiker,
                        "TEMPBAN",
                        reden,
                        case_id,
                        interaction.channel,
                        "tempban",
                    )
                    await ch.send(embed=embed)

        except Exception as e:
            await interaction.response.send_message(
                embed=get_embed_error(f"Fout bij tempban: {e}"), ephemeral=True
            )


async def setup(bot):
    await bot.add_cog(TempBans(bot))
