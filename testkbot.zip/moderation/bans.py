import json
import os
from datetime import datetime

import discord
from discord import app_commands
from discord.ext import commands

from utils.templates import (
    get_embed_ban,
    get_embed_ban_dm,
    get_embed_bans_list,
    get_embed_confirm,
    get_embed_error,
    get_embed_mod_log,
)


class Bans(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bans_file = "data/bans.json"

    def get_data(self):
        if not os.path.exists(self.bans_file):
            if not os.path.exists("data"):
                os.makedirs("data")
            with open(self.bans_file, "w") as f:
                json.dump({"cases": []}, f)
            return {"cases": []}
        with open(self.bans_file, "r") as f:
            return json.load(f)

    def save_data(self, data):
        with open(self.bans_file, "w") as f:
            json.dump(data, f, indent=4)

    async def log_to_mod_logs(
        self, interaction, action, user, reason=None, case_id=None, command_name=None
    ):
        """Stuurt de log naar het mod-logs kanaal."""
        mod_log_id = os.getenv("CHANNEL_MOD_LOGS_ID")
        if not mod_log_id:
            return

        ch = interaction.guild.get_channel(int(mod_log_id))
        if ch:
            embed = get_embed_mod_log(
                moderator=interaction.user,
                user=user,
                action=action,
                reason=reason,
                case_id=case_id,
                channel=interaction.channel,
                command_name=command_name,
            )
            await ch.send(embed=embed)

    @app_commands.command(name="ban", description="Ban een gebruiker permanent")
    @app_commands.describe(wis_berichten="Aantal dagen geschiedenis om te wissen (0-7)")
    @app_commands.checks.has_permissions(ban_members=True)
    async def ban(
        self,
        interaction: discord.Interaction,
        gebruiker: discord.User,
        reden: str,
        wis_berichten: int = 0,
    ):
        if (
            isinstance(gebruiker, discord.Member)
            and gebruiker.top_role >= interaction.user.top_role
        ):
            return await interaction.response.send_message(
                embed=get_embed_error("Je kunt deze persoon niet bannen."),
                ephemeral=True,
            )

        data = self.get_data()

        all_ids = [c["case_id"] for c in data["cases"]]
        for cog_name in ["Warnings", "Mutes", "Kick"]:
            cog = self.bot.get_cog(cog_name)
            if cog and hasattr(cog, "get_data"):
                all_ids.extend([c["case_id"] for c in cog.get_data()["cases"]])

        case_id = (max(all_ids) + 1) if all_ids else 1

        try:
            await gebruiker.send(embed=get_embed_ban_dm(interaction.guild.name, reden))
        except:  # noqa: E722
            pass

        try:
            days = max(0, min(wis_berichten, 7))
            await interaction.guild.ban(
                gebruiker, reason=f"Case {case_id} | {reden}", delete_message_days=days
            )

            new_case = {
                "case_id": case_id,
                "user_id": gebruiker.id,
                "user_name": gebruiker.name,
                "mod_name": interaction.user.name,
                "reason": reden,
                "duration": "Permanent",
                "timestamp": datetime.now().timestamp(),
            }
            data["cases"].append(new_case)
            self.save_data(data)

            await interaction.response.send_message(
                embed=get_embed_confirm(
                    f"**{gebruiker.name}** is verbannen (berichten gewist: {days}d)."
                ),
                ephemeral=True,
            )

            s_ch_id = os.getenv("CHANNEL_STRAFFEN_ID")
            if s_ch_id:
                s_ch = interaction.guild.get_channel(int(s_ch_id))
                if s_ch:
                    await s_ch.send(
                        embed=get_embed_ban(gebruiker, interaction.user, reden, case_id)
                    )

            await self.log_to_mod_logs(
                interaction=interaction,
                action="BAN",
                user=gebruiker,
                reason=reden,
                case_id=case_id,
                command_name="ban",
            )

        except Exception as e:
            await interaction.response.send_message(
                embed=get_embed_error(f"Fout bij uitvoeren ban: {e}"), ephemeral=True
            )

    @app_commands.command(
        name="unban", description="Hef een verbanning op van een gebruiker"
    )
    @app_commands.describe(
        user_id="Het ID van de gebruiker", reden="Reden voor de unban"
    )
    @app_commands.checks.has_permissions(ban_members=True)
    async def unban(self, interaction: discord.Interaction, user_id: str, reden: str):
        try:
            user = await self.bot.fetch_user(int(user_id))
        except:  # noqa: E722
            return await interaction.response.send_message(
                embed=get_embed_error("Gebruiker niet gevonden. Controleer het ID."),
                ephemeral=True,
            )

        try:
            await interaction.guild.unban(
                user, reason=f"Unban door {interaction.user.name} | {reden}"
            )

            data = self.get_data()
            changed = False
            for case in data["cases"]:
                # Markeer actieve cases als geunband in de historie
                if case["user_id"] == user.id and (
                    case["duration"] == "Permanent" or "expiry" in case
                ):
                    if "expiry" in case:
                        case["duration"] = f"Unbanned ({case['duration']})"
                        del case["expiry"]
                    else:
                        case["duration"] = "Unbanned (Permanent)"
                    changed = True

            if changed:
                self.save_data(data)

            await interaction.response.send_message(
                embed=get_embed_confirm(f"**{user.name}** is succesvol geunbanned."),
                ephemeral=True,
            )
            await self.log_to_mod_logs(
                interaction, "UNBAN", user, reden, command_name="unban"
            )

        except discord.NotFound:
            await interaction.response.send_message(
                embed=get_embed_error("Deze gebruiker is niet verbannen."),
                ephemeral=True,
            )
        except Exception as e:
            await interaction.response.send_message(
                embed=get_embed_error(f"Fout: {e}"), ephemeral=True
            )

    @app_commands.command(
        name="banlist", description="Toon ban historie van een gebruiker"
    )
    @app_commands.checks.has_permissions(moderate_members=True)
    async def banlist(self, interaction: discord.Interaction, gebruiker: discord.User):
        data = self.get_data()
        user_cases = [c for c in data["cases"] if c["user_id"] == gebruiker.id]

        embed = get_embed_bans_list(gebruiker, user_cases)
        await interaction.response.send_message(embed=embed, ephemeral=True)

        await self.log_to_mod_logs(
            interaction, action="VIEW_BANLIST", user=gebruiker, command_name="banlist"
        )


async def setup(bot):
    await bot.add_cog(Bans(bot))
