import discord
from discord import app_commands
from discord.ext import commands

from utils.templates.system import get_embed_history


class History(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(
        name="history",
        description="Toon de volledige moderatie historie van een gebruiker",
    )
    @app_commands.checks.has_permissions(moderate_members=True)
    async def history(self, interaction: discord.Interaction, gebruiker: discord.User):
        # Haal alle Cogs op
        warns_cog = self.bot.get_cog("Warnings")
        mutes_cog = self.bot.get_cog("Mutes")
        kicks_cog = self.bot.get_cog("Kick")
        bans_cog = self.bot.get_cog("Bans")  # Nieuw: Bans cog ophalen

        # Data ophalen (met fail-safe als een cog niet geladen is)
        warn_data = (
            warns_cog.get_data()
            if warns_cog and hasattr(warns_cog, "get_data")
            else {"cases": []}
        )
        mute_data = (
            mutes_cog.get_data()
            if mutes_cog and hasattr(mutes_cog, "get_data")
            else {"cases": []}
        )
        kick_data = (
            kicks_cog.get_data()
            if kicks_cog and hasattr(kicks_cog, "get_data")
            else {"cases": []}
        )
        ban_data = (
            bans_cog.get_data()
            if bans_cog and hasattr(bans_cog, "get_data")
            else {"cases": []}
        )

        # Filter de data op de specifieke gebruiker
        user_warns = [c for c in warn_data["cases"] if c["user_id"] == gebruiker.id]
        user_mutes = [c for c in mute_data["cases"] if c["user_id"] == gebruiker.id]
        user_kicks = [c for c in kick_data["cases"] if c["user_id"] == gebruiker.id]
        user_bans = [
            c for c in ban_data["cases"] if c["user_id"] == gebruiker.id
        ]  # Nieuw: Bans filteren

        # Genereer de embed (Zorg dat system.py is bijgewerkt met de 'bans' parameter!)
        embed = get_embed_history(
            gebruiker, user_warns, user_mutes, user_kicks, user_bans
        )

        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(History(bot))
