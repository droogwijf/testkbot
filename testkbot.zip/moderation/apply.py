import asyncio
import base64
import os
from datetime import datetime

import aiohttp
import chat_exporter
import discord
from discord import app_commands
from discord.ext import commands

PANEL_COLOR = 0xD50905
GRAY = "\033[90m"
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
END = "\033[0m"


def log_terminal(category: str, message: str, color_code: str):
    timestamp = datetime.now().strftime("%H:%M:%S")
    cat_fixed = f"[{category.upper()}]".ljust(14)
    print(f"{GRAY}{timestamp}{END} {color_code}{cat_fixed}{END} {message}")


class TicketActions(discord.ui.View):
    def __init__(self, cog):
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(
        label="Sluit Sollicitatie",
        style=discord.ButtonStyle.danger,
        emoji="🔒",
        custom_id="close_ticket_btn",
    )
    async def close_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        if interaction.user.guild_permissions.manage_roles:
            await self.cog.close_logic(interaction)
        else:
            await interaction.response.send_message(
                "Slechts staffleden kunnen dit ticket sluiten.", ephemeral=True
            )


class SollicitatieButtons(discord.ui.View):
    def __init__(self, cog):
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(
        label="Solliciteer",
        style=discord.ButtonStyle.danger,
        emoji="📝",
        custom_id="solli_btn_kb",
    )
    async def solliciteer(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ):
        await interaction.response.send_modal(
            SollicitatieModal(min_leeftijd=16, cog=self.cog)
        )


class SollicitatieModal(discord.ui.Modal):
    def __init__(self, min_leeftijd, cog):
        super().__init__(title="Sollicitatie → Helper")
        self.min_leeftijd = min_leeftijd
        self.cog = cog

        self.naam = discord.ui.TextInput(
            label="Wat is je naam?",
            placeholder="Voor- of gebruikersnaam.",
            min_length=2,
            max_length=16,
            required=True,
        )
        self.leeftijd = discord.ui.TextInput(
            label="Wat is je leeftijd?",
            placeholder="Vul een getal in.",
            min_length=2,
            max_length=2,
            required=True,
        )
        self.ervaring = discord.ui.TextInput(
            label="Staffervaring en verwachtingen.",
            style=discord.TextStyle.long,
            placeholder="Vertel over je vorige ervaringen en wat je verwachtingen zijn.",
            min_length=1,
            max_length=1000,
            required=True,
        )
        self.motivatie = discord.ui.TextInput(
            label="Wat is je motivatie?",
            style=discord.TextStyle.long,
            placeholder="Waarom wil je bij ons team komen?",
            min_length=300,
            max_length=1200,
            required=True,
        )

        self.add_item(self.naam)
        self.add_item(self.leeftijd)
        self.add_item(self.ervaring)
        self.add_item(self.motivatie)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        try:
            leeftijd_getal = int(self.leeftijd.value)
            if leeftijd_getal < self.min_leeftijd:
                return await interaction.followup.send(
                    f"Je bent helaas nog te jong. Minimumleeftijd is {self.min_leeftijd}.",
                    ephemeral=True,
                )
        except ValueError:
            return await interaction.followup.send(
                "Voer een geldig getal in bij leeftijd.", ephemeral=True
            )

        guild = interaction.guild
        category = guild.get_channel(int(os.getenv("CATEGORY_SOLLICITATIES_ID")))
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(
                view_channel=True, send_messages=True, attach_files=True
            ),
        }

        for r_id in [
            "ROLE_HELPER_ID",
            "ROLE_MODERATOR_ID",
            "ROLE_ADMINISTRATOR_ID",
            "ROLE_EIGENAAR_ID",
        ]:
            role = guild.get_role(int(os.getenv(r_id)))
            if role:
                overwrites[role] = discord.PermissionOverwrite(
                    view_channel=True, send_messages=True
                )

        clean_name = self.naam.value.replace(" ", "-").lower()
        channel = await guild.create_text_channel(
            name=f"📝-{clean_name}", category=category, overwrites=overwrites
        )

        embed = discord.Embed(
            description="Bedankt voor je sollicitatie! Het team zal je aanvraag bekijken.",
            color=PANEL_COLOR,
        )
        embed.set_author(
            name=f"{interaction.user.name} | {self.naam.value}",
            icon_url=interaction.user.display_avatar.url,
        )
        embed.add_field(name="Naam", value=self.naam.value, inline=True)
        embed.add_field(
            name="Leeftijd", value=f"{self.leeftijd.value} jaar", inline=True
        )
        embed.add_field(name="Functie", value="Helper", inline=True)
        embed.add_field(name="Ervaring", value=self.ervaring.value, inline=False)
        embed.add_field(name="Motivatie", value=self.motivatie.value, inline=False)
        embed.set_footer(
            text=f"Ingediend op {datetime.now().strftime('%d-%m-%Y %H:%M')}"
        )

        if os.path.exists("bot_banner.png"):
            file = discord.File("bot_banner.png", filename="banner.png")
            embed.set_image(url="attachment://banner.png")
            msg = await channel.send(
                content=f"Welkom {interaction.user.mention}!",
                embed=embed,
                file=file,
                view=TicketActions(self.cog),
            )
        else:
            msg = await channel.send(
                content=f"Welkom {interaction.user.mention}!",
                embed=embed,
                view=TicketActions(self.cog),
            )

        await msg.pin()
        log_terminal(
            "APPLY", f"Nieuw ticket: {channel.name} door {interaction.user.name}", GREEN
        )
        await interaction.followup.send(
            f"→ Je sollicitatie ticket is aangemaakt: {channel.mention}", ephemeral=True
        )


class SollicitatiePanel(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    solli_group = app_commands.Group(
        name="sollicitatie", description="Beheer sollicitaties"
    )

    async def close_logic(self, interaction: discord.Interaction):
        await interaction.response.send_message(
            "→ Transcript maken en ticket sluiten...", ephemeral=True
        )

        t_stamp = datetime.now().strftime("%d-%m-%Y-%H:%M")

        folder_path = "meneerkbot/sollicitaties"
        filename = f"{folder_path}/{interaction.channel.name}-{t_stamp}.html"

        staff_roles = [
            int(os.getenv("ROLE_HELPER_ID")),
            int(os.getenv("ROLE_MODERATOR_ID")),
            int(os.getenv("ROLE_ADMINISTRATOR_ID")),
            int(os.getenv("ROLE_EIGENAAR_ID")),
        ]

        opener = "Onbekend"
        for target in interaction.channel.overwrites:
            if isinstance(target, discord.Member) and not target.bot:
                if not any(r.id in staff_roles for r in target.roles):
                    opener = target.mention
                    break

        link = None
        try:
            transcript = await chat_exporter.export(interaction.channel)
            if transcript:
                token, repo = os.getenv("GITHUB_TOKEN"), os.getenv("GITHUB_REPO")
                url = f"https://api.github.com/repos/{repo}/contents/{filename}"

                payload = {
                    "message": f"Log: apply-{interaction.channel.name}",
                    "content": base64.b64encode(transcript.encode("utf-8")).decode(
                        "utf-8"
                    ),
                }
                headers = {
                    "Authorization": f"token {token}",
                    "Accept": "application/vnd.github.v3+json",
                }

                async with aiohttp.ClientSession() as session:
                    async with session.put(url, json=payload, headers=headers) as resp:
                        if resp.status in [200, 201]:
                            u, r = repo.split("/")
                            link = f"https://{u}.github.io/{r}/{filename}"
                            log_terminal(
                                "GITHUB",
                                f"Transcript opgeslagen in {folder_path}",
                                GREEN,
                            )
                        else:
                            res = await resp.json()
                            log_terminal(
                                "ERROR", f"GitHub Fout: {res.get('message')}", RED
                            )
        except Exception as e:
            log_terminal("ERROR", f"Transcript fout: {e}", RED)

        log_channel = interaction.guild.get_channel(
            int(os.getenv("CHANNEL_SOLLICITATIE_LOG_ID"))
        )
        if log_channel:
            log_embed = discord.Embed(
                title="📝 Sollicitatie Logboek", color=PANEL_COLOR
            )
            log_embed.description = (
                f"De sollicitatie van `{interaction.channel.name}` is gesloten."
            )
            log_embed.add_field(name="👤 Sollicitant", value=opener, inline=True)
            log_embed.add_field(
                name="🔒 Gesloten door", value=interaction.user.mention, inline=True
            )
            log_embed.set_footer(text=f"ID: {interaction.channel.id}")

            view = discord.ui.View()
            if link:
                view.add_item(
                    discord.ui.Button(
                        label="Bekijk Transcript",
                        url=link,
                        style=discord.ButtonStyle.link,
                        emoji="🔗",
                    )
                )

            await log_channel.send(embed=log_embed, view=view)

        log_terminal("APPLY", f"Ticket {interaction.channel.name} verwijderd.", YELLOW)
        await asyncio.sleep(2)
        await interaction.channel.delete()

    @solli_group.command(name="setup", description="Plaats het sollicitatie paneel")
    @app_commands.default_permissions(manage_messages=True)
    async def setup(self, interaction: discord.Interaction):
        guild = interaction.guild
        embed = discord.Embed(color=PANEL_COLOR)
        embed.set_author(
            name=f"{guild.name} – Solliciteren",
            icon_url=guild.icon.url if guild.icon else None,
        )
        embed.title = "Word jij onze nieuwe Helper?"
        embed.description = (
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "Wij zijn op zoek naar een gemotiveerde helper (minimaal 16) om ons team te versterken!\n\n"
            "**Wat moet je kunnen?**\n"
            "• Modereren van de chat\n• Leuke polls kunnen maken\n• Hosten van kleine Discord events\n\n"
            "**Hoe werkt het?**\n"
            "Klik op de knop hieronder en vul het formulier in.\n\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━"
        )

        if os.path.exists("bot_banner.png"):
            file = discord.File("bot_banner.png", filename="banner.png")
            embed.set_image(url="attachment://banner.png")
            await interaction.channel.send(
                embed=embed, file=file, view=SollicitatieButtons(self)
            )
        else:
            await interaction.channel.send(embed=embed, view=SollicitatieButtons(self))

        await interaction.response.send_message(
            "→ Sollicitatie paneel geplaatst.", ephemeral=True
        )

    @solli_group.command(name="accept", description="Accepteer een nieuwe helper")
    @app_commands.default_permissions(manage_roles=True)
    async def accept(self, interaction: discord.Interaction, gebruiker: discord.Member):
        role = interaction.guild.get_role(int(os.getenv("ROLE_HELPER_ID")))
        if role:
            await gebruiker.add_roles(role)
            await interaction.response.send_message(
                f"🎉 Gefeliciteerd {gebruiker.mention} je bent aangenomen als Helper!"
            )
            log_terminal(
                "APPLY",
                f"{gebruiker.name} aangenomen door {interaction.user.name}",
                GREEN,
            )
        else:
            await interaction.response.send_message(
                "Kon de Helper-rol niet vinden.", ephemeral=True
            )


async def setup(bot):
    await bot.add_cog(SollicitatiePanel(bot))
