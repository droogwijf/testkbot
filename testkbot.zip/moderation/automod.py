import os

from discord.ext import commands


class AutoMod(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.allowed_roles = [
            int(os.getenv("ROLE_HELPER_ID", 0)),
            int(os.getenv("ROLE_MODERATOR_ID", 0)),
            int(os.getenv("ROLE_ADMINISTRATOR_ID", 0)),
            int(os.getenv("ROLE_EIGENAAR_ID", 0)),
        ]
        self.mod_log_channel_id = int(os.getenv("CHANNEL_MOD_LOGS_ID", 0))
        print(f"AutoMod geladen. Log kanaal ID: {self.mod_log_channel_id}")

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return

        content = message.content.lower()
        if "@everyone" in content or "@here" in content or message.mention_everyone:

            print(f"DEBUG: Tag poging van {message.author.name}")

            user_role_ids = [role.id for role in message.author.roles]
            is_staff = any(role_id in self.allowed_roles for role_id in user_role_ids)

            if not is_staff:
                await message.channel.send(
                    f"{message.author.mention} wat doe je nou pannenkoek?!",
                    reference=message,
                )

                log_channel = self.bot.get_channel(self.mod_log_channel_id)
                if log_channel:
                    await log_channel.send(
                        f"🥞 Pannenkoek Alert 🥞\n{message.author.mention} probeerde te taggen in {message.channel.mention}"
                    )
                else:
                    print(
                        f"FOUT: Kon mod-log kanaal met ID {self.mod_log_channel_id} niet vinden."
                    )
            else:
                print(f"DEBUG: {message.author.name} is staff, ik doe niets.")


async def setup(bot):
    await bot.add_cog(AutoMod(bot))
